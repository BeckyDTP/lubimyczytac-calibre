#!/usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fileencoding=UTF-8:ts=4:sw=4:sta:et:sts=4:ai
from __future__ import (unicode_literals, division, absolute_import, print_function)

__license__   = 'GPL v3'
__copyright__ = '2014, Roman Cupisz <roman.cupisz+calibre@gmail.com>, 2015-2026 enhancements by Becky <becky@fr.pl>'
__docformat__ = 'restructuredtext en'

# import six
from six import text_type as unicode

# from itertools import compress

import socket
import re
import datetime
# from collections import OrderedDict
from threading import Thread

from lxml.html import fromstring
from lxml.html import tostring

from calibre.ebooks.metadata.book.base import Metadata
from calibre.library.comments import sanitize_comments_html
from calibre.utils.cleantext import clean_ascii_chars
from calibre.ebooks.metadata import check_isbn
# from calibre.utils.icu import capitalize, lower

from calibre.ebooks.metadata.sources.base import fixauthors

import mechanize
from mechanize import HTTPError

from . import config as cfg

import json

# import win32api

frazastrona = ["strona", "strony", "stron"]

import time
from calibre.constants import DEBUG
from calibre import prints

# Reczna flaga diagnostyki parserow (niezalezna od calibre.constants.DEBUG).
BECKYDEBUG = True

BASE_TIME = None

def debug_print(*args):
    global BASE_TIME
    if BASE_TIME is None:
        BASE_TIME = time.time()
    if DEBUG:
        prints('DEBUG: %6.1f'%(time.time()-BASE_TIME), *args)


class Worker(Thread):  # Get details

    '''
    Get book details from LubimyCzytac.pl book page in a separate thread
    '''

    def __init__(self, url, result_queue, browser, log, relevance, plugin, timeout=20, target_isbn=None):
        Thread.__init__(self)
        self.daemon = True
        self.url, self.result_queue = url, result_queue
        self.log, self.timeout = log, timeout
        self.relevance, self.plugin = relevance, plugin
        self.target_isbn = target_isbn
        self.browser = browser.clone_browser()
        self.cover_url = self.lubimy_czytac_id = self.isbn = None
        # Szczegolowy rejestr prob parserow, wykorzystywany w diagnostyce.
        self.parse_diagnostics = []
        self._diagnostic_attempts = {}

    def run(self):
        try:
            self.get_details()
        except:
            self.log.exception('get_details failed for url: %r'%self.url)

    def _diagnostic_value(self, value):
        if value is None or value == '' or value == []:
            return 'Brak'
        try:
            text = unicode(value)
        except Exception:
            text = repr(value)
        text = ' '.join(text.split())
        if len(text) > 240:
            text = text[:237] + '...'
        return text

    def record_parse_attempt(self, field, source, value, error=None):
        """Zapisuje wynik pojedynczej proby pobrania pola."""
        attempt = self._diagnostic_attempts.get(field, 0) + 1
        self._diagnostic_attempts[field] = attempt
        if source == 'XPath':
            source = 'XPath proba #%d' % attempt
        self.parse_diagnostics.append({
            'field': field,
            'source': source,
            'value': self._diagnostic_value(value),
            'error': unicode(error) if error else None,
        })

    def log_parse_diagnostics(self):
        """Wypisuje raport, gdy reczna flaga BECKYDEBUG jest wlaczona."""
        if not BECKYDEBUG:
            return
        self.log.info('BECKYDEBUG: aktywny; worker=%s; zarejestrowanych prob=%d' %
                      (__file__, len(self.parse_diagnostics)))
        if not self.parse_diagnostics:
            self.log.info('BECKYDEBUG: brak zarejestrowanych prob parse_first()')
            return
        self.log.info('--- RAPORT DIAGNOSTYCZNY PARSOWANIA LC ---')
        current_field = None
        for item in self.parse_diagnostics:
            if item['field'] != current_field:
                current_field = item['field']
                self.log.info('[%s]' % current_field)
            line = '  %s: %s' % (item['source'], item['value'])
            if item['error']:
                line += ' (wyjatek: %s)' % item['error']
            self.log.info(line)
        self.log.info('--- KONIEC RAPORTU DIAGNOSTYCZNEGO ---')

    def parse_first(self, root, xpath, loginfo, convert=lambda x: x[0].strip()):
        try:
            nodes = root.xpath(xpath)
            if nodes:
                value = convert(nodes)
                nodes_temp = strip_accents(unicode(str(value)))
                self.log.info('BECKY INFO: Found %s: %s' % (loginfo,nodes_temp))
                self.record_parse_attempt(loginfo, 'XPath', value)
                return value
            self.record_parse_attempt(loginfo, 'XPath', None)
            return None
        except Exception as e:
            self.record_parse_attempt(loginfo, 'XPath', None, e)
            self.log.exception('Error parsing for %s with xpath: %s' % (loginfo, xpath))

    def get_details(self):
        try:
            self.log.info('LubimyCzytac.pl   url: %r'%self.url)
            response = self.browser.open_novisit(self.url, timeout=self.timeout)
            raw = response.read().strip()
        except HTTPError as e:
            self.log.error(f"HTTP Error: {e}")
            if e.code == 500:
                self.log.error('Serwis LubimyCzytac domyślnie zwraca blad 500.')
                self.log.error('To nie jest problem zwiazany z wtyczka!')
                # Pobieramy zawartość odpowiedzi, nawet jeśli wystąpił błąd 500
                raw = e.read().strip()
                self.log.info("Probuje parsowac strone pomimo bledu 500")
            else:
                self.log.error("Inny blad HTTP, nie mozna pobrac danych")
                return
        except Exception as e:
            if callable(getattr(e, 'getcode', None)) and \
                    e.getcode() == 404:
                self.log.error('URL malformed: %r'%self.url)
                return
            if callable(getattr(e, 'getcode', None)) and \
                    e.getcode() == 503:
                self.log.error('Serwis LubimyCzytac jest niedostepny.')
                self.log.error('To nie jest problem zwiazany z wtyczka!')
                return
            if callable(getattr(e, 'getcode', None)) and \
                    e.getcode() == 500:
                self.log.error('Serwis LubimyCzytac domyślnie zwraca blad 500.')
                self.log.error('To nie jest problem zwiazany z wtyczka!')
                return
            attr = getattr(e, 'args', [None])
            attr = attr if attr else [None]
            if isinstance(attr[0], socket.timeout):
                msg = 'LubimyCzytac.pl timed out. Try again later.'
                self.log.error(msg)
            else:
                msg = 'Failed to make details query: %r'%self.url
                self.log.exception(msg)
            return

        raw = raw.decode('utf-8', errors='replace')
        # open('D:\\Tools\\WORKSPACE\\LC\\log_becky_worker.html', 'w').write(raw)
        '''
        f = open("D:\\Tools\\WORKSPACE\\LC\\log_becky_worker.html", "w")
        try:
            f.write(raw.rstrip('\n') )
        finally:
            f.close()
        '''

        if 'Przepraszamy, nie możemy znaleźć strony, której szukasz.' in raw:
            self.log.error('URL malformed: %r'%self.url)
            return

        try:
            root = fromstring(clean_ascii_chars(raw.encode("utf-8")))
        except:
            msg = 'Failed to parse LubimyCzytac.pl details page: %r'%self.url
            self.log.exception(msg)
            return

        if self.target_isbn:
            try:
                matched = self.find_edition_by_isbn(root)
                if matched:
                    self.url, root = matched
                    self.log.info('ISBN-EDITION: WYBRANO WYDANIE ZGODNE Z ISBN: %s' % self.url)
            except Exception:
                # Nie przerywamy identyfikacji: w razie błędu pozostaje pierwotny wynik.
                self.log.exception('ISBN-EDITION: sprawdzanie innych wydan nie powiodlo sie; pozostaje pierwotny wynik')

        self.parse_details(root)

    def _normalize_isbn_test(self, value):
        if not value:
            return None
        value = re.sub(r'[^0-9Xx]', '', unicode(value)).upper()
        return value or None

    def _isbn_from_root(self, root):
        values = root.xpath('//meta[@property="books:isbn"]/@content')
        if not values:
            values = root.xpath('//div[@id="book-details"]//dt[contains(text(),"ISBN:")]/following-sibling::dd[1]//text()')
        return self._normalize_isbn_test(' '.join(values).strip() if values else None)

    def find_edition_by_isbn(self, root):
        """Znajduje powiazane wydanie ksiazki z ISBN zgodnym z ISBN z Calibre.

        Przy braku zgodnosci zwraca None, pozostawiajac dotychczasowy wynik.
        """
        target = self._normalize_isbn_test(self.target_isbn)
        if not target:
            return None
        self.log.info('ISBN-EDITION: ISBN z Calibre: %s' % target)

        # Jeśli pierwotny wynik już ma dokładnie właściwy ISBN, nie wykonujemy dodatkowych żądań.
        current_isbn = self._isbn_from_root(root)
        if current_isbn == target:
            self.log.info('ISBN-EDITION: pierwotny wynik ma zgodny ISBN; pomijam szczegolowe sprawdzanie innych wydan')
            return None

        match = re.search(r'/ksiazka/(\d+)(?:/([^/?#]+))?', self.url)
        if not match:
            self.log.info('ISBN-EDITION: URL nie jest strona ksiazki; pomijam wyszukiwanie wydan')
            return None
        editions_url = 'https://lubimyczytac.pl/ksiazka/wydania/' + match.group(1)
        if match.group(2):
            editions_url += '/' + match.group(2)
        self.log.info('ISBN-EDITION: pobieram liste: %s' % editions_url)
        response = self.browser.open_novisit(editions_url, timeout=self.timeout)
        raw = response.read().strip()
        if not isinstance(raw, unicode):
            raw = raw.decode('utf-8', errors='replace')
        editions_root = fromstring(clean_ascii_chars(raw.encode('utf-8')))
        nodes = editions_root.xpath('//div[@id="editionsList"]//a[contains(concat(" ", normalize-space(@class), " "), " book-card__title ")]')
        self.log.info('ISBN-EDITION: liczba pozycji na liscie: %d' % len(nodes))
        seen = set()
        for node in nodes:
            href = node.get('href')
            title = ' '.join(''.join(node.itertext()).split())
            if not href:
                continue
            if href.startswith('/'):
                href = 'https://lubimyczytac.pl' + href
            # Wydanie ma być książką, nie audiobookiem.
            if '/ksiazka/' not in href:
                self.log.info('ISBN-EDITION: pomijam nie-ksiazkowa pozycje: %s' % href)
                continue
            if href in seen:
                continue
            seen.add(href)
            # Nie pobieramy ponownie strony pierwotnego kandydata.
            if href.rstrip('/') == self.url.rstrip('/'):
                continue
            try:
                detail_response = self.browser.open_novisit(href, timeout=self.timeout)
                detail_raw = detail_response.read().strip()
                if not isinstance(detail_raw, unicode):
                    detail_raw = detail_raw.decode('utf-8', errors='replace')
                detail_root = fromstring(clean_ascii_chars(detail_raw.encode('utf-8')))
                isbn = self._isbn_from_root(detail_root)
                self.log.info('ISBN-EDITION: %s | ISBN=%s | %s' % (title, isbn or 'BRAK', href))
                if isbn == target:
                    self.log.info('ISBN-EDITION: DOKLADNA ZGODNOSC: %s | %s' % (target, href))
                    # Natychmiast konczymy: dalsze strony wydań nie są już potrzebne.
                    return href, detail_root
            except Exception as e:
                self.log.info('ISBN-EDITION: nie udalo sie odczytac %s: %s' % (href, e))
        self.log.info('ISBN-EDITION: brak zgodnego ISBN; pozostaje pierwotne wydanie')
        return None

    def parse_details(self, root):
        self.log.info('---------------------------------  PARSOWANIE  ---------------------------------')
        append_pages = cfg.plugin_prefs[cfg.STORE_NAME].get(cfg.APPEND_PAGES, cfg.DEFAULT_STORE_VALUES[cfg.APPEND_PAGES])
        append_pages_new = cfg.plugin_prefs[cfg.STORE_NAME].get(cfg.APPEND_PAGES_NEW, cfg.DEFAULT_STORE_VALUES[cfg.APPEND_PAGES_NEW])
        append_original_title = cfg.plugin_prefs[cfg.STORE_NAME].get(cfg.APPEND_ORIGINAL_TITLE, cfg.DEFAULT_STORE_VALUES[cfg.APPEND_ORIGINAL_TITLE])
        append_translators = cfg.plugin_prefs[cfg.STORE_NAME].get(cfg.APPEND_TRANSLATION, cfg.DEFAULT_STORE_VALUES[cfg.APPEND_TRANSLATION])
        append_serwyd = cfg.plugin_prefs[cfg.STORE_NAME].get(cfg.APPEND_SERWYD, cfg.DEFAULT_STORE_VALUES[cfg.APPEND_SERWYD])
        append_kategoria = cfg.plugin_prefs[cfg.STORE_NAME].get(cfg.APPEND_GENRE, cfg.DEFAULT_STORE_VALUES[cfg.APPEND_GENRE])
        append_keywords = cfg.plugin_prefs[cfg.STORE_NAME].get(cfg.APPEND_KEYWORDS, cfg.DEFAULT_STORE_VALUES[cfg.APPEND_KEYWORDS])
        append_rating = cfg.plugin_prefs[cfg.STORE_NAME].get(cfg.APPEND_RATING, cfg.DEFAULT_STORE_VALUES[cfg.APPEND_RATING])
        append_rating_counts = cfg.plugin_prefs[cfg.STORE_NAME].get(cfg.APPEND_RATING_COUNT, cfg.DEFAULT_STORE_VALUES[cfg.APPEND_RATING_COUNT])
        append_id = cfg.plugin_prefs[cfg.STORE_NAME].get(cfg.APPEND_ID, cfg.DEFAULT_STORE_VALUES[cfg.APPEND_ID])
        before_other_editions_exist = cfg.plugin_prefs[cfg.STORE_NAME].get(cfg.BEFORE_OTHER_EDITIONS_EXIST, cfg.DEFAULT_STORE_VALUES[cfg.BEFORE_OTHER_EDITIONS_EXIST])
        before_other_editions_all = cfg.plugin_prefs[cfg.STORE_NAME].get(cfg.BEFORE_OTHER_EDITIONS_ALL, cfg.DEFAULT_STORE_VALUES[cfg.BEFORE_OTHER_EDITIONS_ALL])
        before_other_editions_short = cfg.plugin_prefs[cfg.STORE_NAME].get(cfg.BEFORE_OTHER_EDITIONS_SHORT, cfg.DEFAULT_STORE_VALUES[cfg.BEFORE_OTHER_EDITIONS_SHORT])
        before_hr = cfg.plugin_prefs[cfg.STORE_NAME].get(cfg.BEFORE_HR, cfg.DEFAULT_STORE_VALUES[cfg.BEFORE_HR])
        asTags = cfg.plugin_prefs[cfg.STORE_NAME].get(cfg.TAGS_AS, cfg.DEFAULT_STORE_VALUES[cfg.TAGS_AS])
        append_first_pubdate = cfg.plugin_prefs[cfg.STORE_NAME].get(cfg.APPEND_FIRST_PUBDATE, cfg.DEFAULT_STORE_VALUES[cfg.APPEND_FIRST_PUBDATE])
        append_first_pubdate_pl = cfg.plugin_prefs[cfg.STORE_NAME].get(cfg.APPEND_FIRST_PUBDATE_PL, cfg.DEFAULT_STORE_VALUES[cfg.APPEND_FIRST_PUBDATE_PL])
        try:
            lubimy_czytac_id = self.parse_lubimy_czytac_id(self.url)
        except:
            self.log.exception('Error parsing LubimyCzytac.pl id for url: %r'%self.url)
            lubimy_czytac_id = None

        try:
            title = self.parse_title(root)
        except:
            self.log.exception('Error parsing title for url: %r'%self.url)
            title = None

        try:
            authors = self.parse_authors(root)
        except:
            self.log.exception('Error parsing authors for url: %r'%self.url)
            authors = []

        # Fix for titles with author 20250826 START
        # jeśli mamy w tytule autora to go usuwamy
        if title and authors:
            title = title.strip()
            # self.log.info('BECKY INFO: title przed poprawieniem: %s'%title)
            for author in authors:
                # self.log.info('BECKY INFO: author roboczy: %s'%author)
                if title.endswith(" - " + author):
                    # self.log.info('BECKY INFO: tak, autor jest w tytule')
                    title = title[:-(len(author) + 3)].strip()
                    break
        # self.log.info('BECKY INFO: title po poprawieniu: %s'%title)
        # Fix for titles with author 20250826 END

        try:
            translators = self.parse_translators(root)
        except:
            self.log.exception('Error parsing translators for url: %r'%self.url)
            translators = []

        if not title or not authors or not lubimy_czytac_id:
            if not title :
                self.log.error('LubimyCzytac.pl_id: %r Title: %r Authors: %r'%(lubimy_czytac_id, title, authors))
                self.log.error('Could not find LubimyCzytac.pl_id or title or authors for %r'%self.url)
            return

        mi = Metadata(title, authors)
        mi.set_identifier('lubimyczytac', lubimy_czytac_id)
        self.lubimy_czytac_id = lubimy_czytac_id

        try:
            serwyd = self.parse_serwyd(root)
        except:
            self.log.exception('Error parsing book series for url: %r'%self.url)
            serwyd = None


        try:
            (series, series_index) = self.parse_series(root)
        except:
            self.log.exception('Error parsing series (cykl) for url: %r'%self.url)
            series = series_index = None
        if series:
            mi.series = series
        if series and series_index:
            mi.series_index = series_index



        replaceISBN = cfg.plugin_prefs[cfg.STORE_NAME].get(cfg.REPLACE_ISBN, cfg.DEFAULT_STORE_VALUES[cfg.REPLACE_ISBN])
        self.log.info('BECKY INFO: Download ISBN number from LC: %s'%replaceISBN)
        if replaceISBN == 1:
            try:
                isbn = self.parse_isbn(root)
                if isbn:
                    self.isbn = mi.isbn = isbn
            except:
                self.log.exception('Error parsing ISBN for url: %r'%self.url)

        try:
            mi.rating = self.parse_rating(root)
        except:
            self.log.exception('Error parsing ratings (stars) for url: %r'%self.url)

        try:
            rating_LC = self.parse_rating_lc(root)
        except:
            self.log.exception('Error parsing ratings (number) for url: %r'%self.url)

        try:
            rating_LC_count = self.parse_rating_lc_count(root)
            # self.log.info('BECKY TEMP: Liczba ocen w LC: %s'%rating_LC_count)
        except:
            self.log.exception('Error parsing ratings counts for url: %r'%self.url)
            rating_LC_count = None

        try:
            pobrane_strony = self.parse_pages(root)
        except:
            self.log.exception('Error parsing pages for url: %r'%self.url)
            pobrane_strony = None

        try:
            tytul_oryginalu = self.parse_tytul_oryginalu(root)
        except:
            self.log.exception('Error parsing original title for url: %r'%self.url)


        first_pubdate = None
        try:
            first_pubdate = self.parse_first_published_date(root)
        except:
            self.log.exception('Error parsing first publication date for url: %r'%self.url)

        first_pubdate_pl = None
        try:
            first_pubdate_pl = self.parse_first_published_date_pl(root)
        except:
            self.log.exception('Error parsing first publication date in Poland for url: %r'%self.url)

        try:
            inne_wydania = self.parse_inne_wydania(root)
            # self.log.info('BECKY INFO: Inne wydania: %s'%inne_wydania)
        except:
            self.log.exception('Error parsing other editions for url: %r'%self.url)

        try:
            inne_wydania_lista = self.parse_inne_wydania_all(root)
            if inne_wydania_lista:
                self.log.info('BECKY INFO: Pelna lista innych wydan\n%s-----'%strip_accents(inne_wydania_lista))
        except:
            self.log.exception('Error parsing list of other editions for url: %r'%self.url)

        try:
            inne_wydania_short_lista = self.parse_inne_wydania_short(root)
            if inne_wydania_short_lista:
                self.log.info('BECKY INFO: Krotka lista innych wydan\n%s-----'%strip_accents(inne_wydania_short_lista).replace('•',  '*'))
        except:
            self.log.exception('Error parsing list of other editions for url: %r'%self.url)

        try:
            tags = self.parse_tags(root)
            tags_keywords = self.parse_tags_keywords(root)
            if asTags == 0:
                if tags:
                    # Komentarz Becky: Download Genre as Tags
                    tags_ze_srednikami = [w.replace(',',  ';') for w in tags]
                    # self.log.info(tags_ze_srednikami)
                    mi.tags = tags_ze_srednikami
                    # self.log.info(mi.tags)
                    self.log.info('BECKY INFO: Do pola Tags/Etykiety dopisano kategorie')
            else:
                if tags_keywords:
                    # Komentarz Becky: Download Keywords as Tags
                    mi.tags = tags_keywords
                    self.log.info('BECKY INFO: Do pola Tags/Etykiety dopisano slowa kluczowe')
            # Beautiful tags (kategorie)
            if tags is not None:
                tags = [re.sub('[a-ząćęłńóśźżA-ZĄĆĘŁŃÓŚŹŻ]', lambda x: x.group().upper(), y, 1) for y in tags]
                tags = ''.join(tags)
            # Beautiful tags (słowa kluczowe)
            if tags_keywords is not None:
                tags_keywords = [re.sub('[a-ząćęłńóśźżA-ZĄĆĘŁŃÓŚŹŻ]', lambda x: x.group().upper(), y, 1) for y in tags_keywords]
        except:
            self.log.exception('Error parsing tags for url: %r'%self.url)

        try:
            try:
                mi.comments = self.parse_comments(root)
            except:
                self.log.exception('Error parsing comments for url: %r' % self.url)
                mi.comments = ''
            if (append_pages == 1) and (pobrane_strony is not None):
                if (append_pages_new == 0):
                    mi.comments = mi.comments + '<p id="strony">Książka ma ' + pobrane_strony + odmiana(pobrane_strony, frazastrona) + '.</p>'
                else:
                    # For new METAmover private release
                    # mi.comments = mi.comments + '<p id="numberOfPages">Liczba stron w książce: ' + pobrane_strony + '</p>'
                    mi.comments = mi.comments + '<p id="numberOfPages">Liczba stron w książce: ' + pobrane_strony + '</p>'
                self.log.info('BECKY INFO: Do komentarza dolaczono liczbe stron')

            if (append_original_title == 1) and (tytul_oryginalu is not None):
                mi.comments = mi.comments + '<p id="tytul_oryginalu">Tytuł oryginału: <em>' + tytul_oryginalu + '</em></p>'
                self.log.info('BECKY INFO: Do komentarza dolaczono tytul oryginalu')

            if (append_translators == 1) and (translators is not None):
                mi.comments = mi.comments + '<p id="tlumaczenie">Tłumaczenie: ' + ', '.join(translators) + '</p>'
                self.log.info('BECKY INFO: Do komentarza dolaczono tlumaczy')

            if (append_serwyd == 1) and (serwyd is not None):
                mi.comments = mi.comments + '<p id="seria">Seria: ' + serwyd + '</p>'
                self.log.info('BECKY INFO: Do komentarza dolaczono nazwe serii wydawniczej')

            if (append_kategoria == 1) and (tags is not None):
                # tags = list(tags)
                # mi.comments = mi.comments + '<p id="kategoria">Kategoria: ' + ', '.join(tags) + '</p>'
                mi.comments = mi.comments + '<p id="kategoria">Kategoria: ' + tags + '</p>'
                self.log.info('BECKY INFO: Do komentarza dolaczono nazwe kategorii')

            if (append_keywords == 1) and (tags_keywords is not None):
                mi.comments = mi.comments + '<p id="slowa_kluczowe">Słowa kluczowe: ' + ', '.join(tags_keywords) + '</p>'
                self.log.info('BECKY INFO: Do komentarza dolaczono slowa kluczowe')

            if (append_rating == 1) and (lubimy_czytac_id is not None) and (rating_LC is not None):
                mi.comments = mi.comments + '<p id="ratingLC">Ocena w LC: ' + rating_LC + '</p>'
                self.log.info('BECKY INFO: Do komentarza dolaczono ocene z serwisu LubimyCzytac')

            if (append_rating_counts == 1) and (lubimy_czytac_id is not None) and (rating_LC_count is not None):
                mi.comments = mi.comments + '<p id="ratingLC_count">Liczba ocen w LC: ' + rating_LC_count + '</p>'
                self.log.info('BECKY INFO: Do komentarza dolaczono liczbe ocen z serwisu LubimyCzytac')

            if (append_first_pubdate == 1) and (first_pubdate is not None):
                mi.comments = mi.comments + '<p id="pierwsze_wydanie">Data pierwszego wydania: ' + first_pubdate.strftime("%d.%m.%Y") + '</p>'
                self.log.info('BECKY INFO: Do komentarza dolaczono date pierwszego wydania')

            if (append_first_pubdate_pl == 1) and (first_pubdate_pl is not None):
                mi.comments = mi.comments + '<p id="pierwsze_wydanie_pl">Data pierwszego wydania w Polsce: ' + first_pubdate_pl.strftime("%d.%m.%Y") + '</p>'
                self.log.info('BECKY INFO: Do komentarza dolaczono date pierwszego wydania w Polsce')

            if (append_id == 1) and (lubimy_czytac_id is not None):
                mi.comments = mi.comments + '<p id="lubimyczytac">ID: ' + lubimy_czytac_id + '</p>'
                self.log.info('BECKY INFO: Do komentarza dolaczono ID z serwisu LubimyCzytac')

            if (before_hr == 1) and (((before_other_editions_all == 1) and (inne_wydania_lista is not None)) or ((before_other_editions_short == 1) and (inne_wydania_short_lista is not None)) or ((before_other_editions_exist == 1) and (inne_wydania is not None))):
                mi.comments = '<hr id="przed-komentarzem">' + mi.comments

            if (before_other_editions_all == 1) and (inne_wydania_lista is not None):
                mi.comments = inne_wydania_lista + mi.comments

            if (before_other_editions_short == 1) and (inne_wydania_short_lista is not None):
                mi.comments = inne_wydania_short_lista + mi.comments

            if (before_other_editions_exist == 1) and (inne_wydania is not None):
                mi.comments = '<p>Inne wydania: <span style="color:red; font-weight: bold;">Istnieją inne wydania</span></p>' + mi.comments

        except:
            self.log.exception('Error parsing comments for url: %r'%self.url)

        try:
            mi.publisher = self.parse_publisher(root)
        except:
            self.log.exception('Error parsing publisher for url: %r'%self.url)

        try:
            mi.pubdate = self.parse_published_date(root)
        except:
            self.log.exception('Error parsing published date for url: %r'%self.url)

        try:
            languages = self.parse_languages(root)
            if languages:
                mi.languages = languages
        except:
            self.log.exception('Error parsing languages for url: %r'%self.url)

        try:
            self.cover_url = self.parse_cover(root)
        except:
            self.log.exception('Error parsing cover for url: %r'%self.url)
        mi.has_cover = bool(self.cover_url)

        #relevance = calc_source_relevance(mi)
        #mi.source_relevance = relevance

        #myrelevance = 0
        #self.log.info('BECKY INFO: -mrb----------------------------------------------')
        #self.log.info('BECKY INFO:    title: %s'%title)
        #self.log.info('BECKY INFO: mi.title: %s'%mi.title)
        #if mi.title == "Test ":
        #    myrelevance += 100
        #self.log.info('BECKY INFO: -mra----------------------------------------------')
        #mi.source_relevance = myrelevance
        #mi.relevance_in_source = myrelevance
        mi.source_relevance = self.relevance
        #self.log.info('BECKY INFO: -rb----------------------------------------------')
        #self.log.info('BECKY INFO: Relevance: %s'%self.relevance)
        #self.log.info('BECKY INFO: Relevance: %s'%myrelevance)
        #self.log.info('BECKY INFO: -ra----------------------------------------------')

        if self.lubimy_czytac_id:
            if self.isbn:
                self.plugin.cache_isbn_to_identifier(self.isbn, self.lubimy_czytac_id)
            if self.cover_url:
                self.plugin.cache_identifier_to_cover_url(self.lubimy_czytac_id, self.cover_url)

        self.clean_downloaded_metadata(mi)
        #self.log.info('BECKY INFO: -rqb----------------------------------------------')
        self.log_parse_diagnostics()
        self.result_queue.put(mi)
        #self.log.info('BECKY INFO: mi: %s'%mi)
        #self.log.info('BECKY INFO: -rqa----------------------------------------------')

    def parse_lubimy_czytac_id(self, url):
        # return re.search('lubimyczytac.pl/ksiazka/(\\d+)/.*', url).groups(0)[0]
        # Audiobooki od wersji 2.3.3
        return re.search('lubimyczytac.pl/(?:ksiazka|audiobook)/(\\d+)/.*', url).groups(1)[0]

    def parse_jsonld_node(self, json_node):
        # LC czasem osadza w JSON-LD surowe znaki kontrolne (np. znaki nowej
        # linii wewnatrz tresci opinii uzytkownikow), co lamie sciezke JSON.
        # strict=False pozwala jsonowi zaakceptowac takie dosłowne znaki
        # kontrolne w stringach zamiast rzucac JSONDecodeError.
        try:
            return json.loads(json_node, strict=False)
        except (ValueError, TypeError):
            return None


    def get_jsonld_data(self, root, field=None):
        """
        Znajduje obiekt Book/Audiobook w JSON-LD i opcjonalnie
        zwraca wskazane pole, np. 'aggregateRating.ratingCount'.
        Obsluguje listy obiektow oraz strukture @graph.
        """

        def iter_objects(data):
            if isinstance(data, list):
                for item in data:
                    for obj in iter_objects(item):
                        yield obj

            elif isinstance(data, dict):
                graph = data.get('@graph')

                if isinstance(graph, list):
                    for item in graph:
                        for obj in iter_objects(item):
                            yield obj

                obj_type = data.get('@type')
                if not isinstance(obj_type, list):
                    obj_type = [obj_type]

                normalized_types = [
                    str(item).rsplit('/', 1)[-1].rsplit('#', 1)[-1]
                    for item in obj_type
                    if item
                ]

                if 'Book' in normalized_types or 'Audiobook' in normalized_types:
                    yield data

        json_nodes = root.xpath(
            '//script[@type="application/ld+json"]/text()'
        )

        for json_node in json_nodes:
            data = self.parse_jsonld_node(json_node)

            if data is None:
                continue

            for book in iter_objects(data):
                if field is None:
                    return book

                value = book
                for key in field.split('.'):
                    if not isinstance(value, dict) or key not in value:
                        value = None
                        break
                    value = value[key]

                if value is not None:
                    return value

        return None


    def parse_title(self, root):

        title_text = u''

        #
        # 1. JSON-LD
        #
        data = self.get_jsonld_data(root)

        if data:

            json_title = data.get('name')

            if json_title:

                title_text = json_title.strip()

                self.log.info(
                    'BECKY INFO: Found title (json): %s'
                    % strip_accents(unicode(str(title_text)))
                )

        #
        # 2. data-title
        #
        if not title_text:

            title_attr = root.xpath(
                '//div[contains(@class,"title-container")]/@data-title'
            )

            if title_attr:

                title_text = title_attr[0].strip()

                self.log.info(
                    'BECKY INFO: Found title (data-title): %s'
                    % strip_accents(unicode(str(title_text)))
                )

        #
        # 3. og:title fallback
        #
        if not title_text:

            try:

                title_text = root.xpath(
                    '//meta[@property="og:title"]/@content'
                )[0]

                title_text = title_text.split("|")[0]

                # LC czasem dodaje autorów po " - "
                if ' - ' in title_text:
                    title_text = title_text.split(' - ')[0]

                self.log.info(
                    'BECKY INFO: Found title (og:title): %s'
                    % strip_accents(unicode(str(title_text)))
                )

            except IndexError:

                self.log.error(
                    'BECKY ERROR: Problem z pobraniem tytulu.'
                )

        #
        # 4. Encje HTML
        #
        if title_text:

            title_text = (
                title_text
                .replace("&amp;", "&")
            )

            liczba_cudzyslowow = title_text.count("&quot;")

            if liczba_cudzyslowow == 2:

                title_text = title_text.replace(
                    "&quot;",
                    "„",
                    1
                )

                title_text = title_text.replace(
                    "&quot;",
                    "”",
                    1
                )

            else:

                title_text = title_text.replace(
                    "&quot;",
                    "\""
                )

            title_text = title_text.strip()

        if not title_text:
            return None

        return title_text


    def parse_authors(self, root):

        authors = []

        # ==========================================
        # 1. META books:author
        # ==========================================

        author_meta = root.xpath(
            '//meta[@property="books:author"]/@content'
        )

        if author_meta:
            authors_raw = author_meta[0]

            # Zamiana encji HTML
            authors_raw = authors_raw.replace('&nbsp;', ' ')

            for author in authors_raw.split(','):
                author = author.strip()

                if author and author not in authors:
                    self.log.info(
                        'BECKY INFO: Found author (meta): %s'
                        % strip_accents(unicode(str(author)))
                    )

                    authors.append(author)

        # ==========================================
        # 2. data-ga-book-authors
        # ==========================================

        if not authors:

            ga_authors = root.xpath(
                '//section[@id="container-book"]/@data-ga-book-authors'
            )

            if ga_authors:
                authors_raw = ga_authors[0]

                for author in authors_raw.split(','):
                    author = author.strip()

                    if author and author not in authors:
                        self.log.info(
                            'BECKY INFO: Found author (data-ga): %s'
                            % strip_accents(unicode(str(author)))
                        )

                        authors.append(author)


        # ==========================================
        # 3. JSON-LD
        # ==========================================

        if not authors:

            author_data = self.get_jsonld_data(root, 'author')

            if isinstance(author_data, dict):
                author_data = [author_data]

            if isinstance(author_data, list):
                for item in author_data:
                    if isinstance(item, dict):
                        author = item.get('name')

                        if isinstance(author, str):
                            author = author.strip()

                            if author and author not in authors:
                                self.log.info(
                                    'BECKY INFO: Found author (json): %s'
                                    % strip_accents(unicode(str(author)))
                                )
                                authors.append(author)

        # ==========================================
        # 4. Ostateczny fallback - HTML
        # ==========================================

        if not authors:

            author_nodes = root.xpath(
                '//span[contains(@class,"author")]//a'
            )

            for author_node in author_nodes:

                if author_node.text is not None:

                    author = author_node.text.strip()

                    if author and author not in authors:

                        self.log.info(
                            'BECKY INFO: Found author (html): %s'
                            % strip_accents(unicode(str(author)))
                        )

                        authors.append(author)

        if not authors:
            self.log.info(
                'Problem z pobraniem autora. Powiadom Becky o tym.'
            )
            return None

        return authors


    # Tłumacze
    def parse_translators(self, root):
        # self.log.info('Start tlumaczy')
        translator_nodes = root.xpath('//section[@class="container book"]//dt[contains(text(),"Tłumacz:")]/following-sibling::dd/a[contains(@href,"/tlumacz/")]')

        if translator_nodes:
            translators = []
            for translator_node in translator_nodes:
                if translator_node.text is not None and translator_node.text not in translators:
                    translator = translator_node.text.strip()
                    self.log.info('BECKY INFO: Found translator: %s'%strip_accents(unicode(str(translator))))
                    translators.append(translator)
            return unique(translators)

    # Seria wydawnicza
    def parse_serwyd(self, root):
        try:
            # self.log.info('try parse serwyd')
            serwyd_node = root.xpath('//section[@class="container book"]//dt[contains(text(),"Seria:")]/following-sibling::dd/a[contains(@href,"/seria/")]/text()')
            # self.log.info('try parse serwyd serwyd_node wersja 1: %s'%serwyd_node)
            if serwyd_node:
                serwyd_lst = root.xpath('//section[@class="container book"]//a[contains(@href,"/seria/")]/text()')
                # self.log.info('try parse serwyd serwyd_lst wersja 1: %s'%serwyd_lst)
                if serwyd_lst:
                    serwyd_txt = serwyd_lst[0]
                    # self.log.info('Jest dobrze (serwyd_txt): %s'%serwyd_txt)
                else:
                    serwyd_txt = None
                # self.log.info('try parse serwyd 1 serwyd_txt: %s'%serwyd_txt)
            else:
                self.log.info('BECKY INFO: Not found book series (Nie znaleziono serii wydawniczej)')
                return None
            serwyd = serwyd_txt.strip()
            self.log.info('BECKY INFO: Found book series (Znaleziono serie wydawnicza): %s'%strip_accents(unicode(serwyd)))
            self.record_parse_attempt('publisher_series', 'HTML seria wydawnicza', serwyd)
            # self.log.info('BECKY INFO: Found book series (Znaleziono serie wydawnicza): %s'%serwyd)
            return serwyd
        except:
            return None

    # Cykl
    def parse_series(self, root):
        try:

            # self.log.info('try parse series')
            series_node = root.xpath('//section[@class="container book"]//span/a[contains(@href,"/cykl/")]')
            # self.log.info('try parse series series_node wersja 1: %s'%series_node)
            if series_node:
                series_lst = root.xpath('//section[@class="container book"]//span/a[contains(@href,"/cykl/")]/text()')
                # self.log.info('try parse series series_lst wersja 1: %s'%series_lst)
                if series_lst:
                    series_txt = series_lst
                    # self.log.info('BECKY INFO: Jest dobrze (series_txt): %s'%series_txt[0].replace('\n','').strip())
                else:
                    series_txt = None
                # self.log.info('try parse series 1 series_txt: %s'%series_txt)
            else:
                # self.log.info('BECKY INFO: Not found series (Nie znaleziono cyklu)')
                return (None, None)

            ser_info = None
            if series_txt:
                # ser_string = root.xpath('//section[@class="container book"]//span[@class="cycle"]/a[contains(@href,"/cykl/")]/text()')
                # self.log.info('try parse series ser_string wersja 1: %s'%ser_string)
                ser_string = [series_txt[0].replace('\n','').strip()]
                # self.log.info('ser_string: %s'%ser_string)
                ser_nazwa = ser_string
                for ser in ser_string:
                    # self.log.info('ser 1: %s'%ser)
                    if 'tom ' in ser:
                        # self.log.info('ser 2: %s'%ser)
                        # self.log.info('try parse series ser: %s'%ser)
                        ser_info = ser.split(' (tom ', 1)
                        # self.log.info('ser_info: %s'%ser_info)
                        ser_nazwa = ser.split(' (tom ')[0]
                        # self.log.info('ser_nazwa: %s'%ser_nazwa)
                        # found = 1
                        break
            # self.log.info('try parse series ser_info: %s'%ser_info)
            # self.log.info('try parse series ser_info[1]: %s'%ser_info[1])
            if ser_info:
                series_index_unicode = ser_info[1]
                # self.log.info('series_index_unicode: %s'%series_index_unicode)
                series_index_string = str(series_index_unicode.replace(" ", "").replace(")", ""))
                # self.log.info('series_index_string: %s'%series_index_string)
                # Sprawdzamy, czy cykl nie jest kompletem/pakietem tomów, np. 1-3
                if "-" in series_index_string:
                    series_index_string_temp = series_index_string.split('-', 1)
                    series_index_string = series_index_string_temp[0]
                if series_index_string.replace(".", "").isdigit() is True:
                    series_index = get_int_or_float(series_index_string)
                else:
                    series_index = 0
                # self.log.info('series_index (liczba): %s'%series_index)

                # self.log.info('try parse series series_index, value and type: %s %s' %(series_index,type(series_index)))
            else:
                series_index = 0
            series = ser_nazwa
            # roman_dict = {'X':10, 'IX':9, 'VIII':8, 'VII':7, 'VI':6, 'V':5, 'IV':4, 'III':3, 'II':2, 'I':1 }
            # series_index = roman_dict.get( series_index,  series_index)
            # self.log.info('BECKY INFO: Found series (znaleziono cykl): (%s, %s)' % (series, series_index))
            self.log.info('BECKY INFO: Found series (znaleziono cykl): (%s, %s)' % (strip_accents(unicode(series)), series_index))
            self.record_parse_attempt('series', 'HTML cykl', (series, series_index))
            return (series, series_index)
        except:
            return (None, None)

    # STARS
    def parse_rating(self, root):
        rating_node = root.xpath('//meta[@property="books:rating:value"]/@content')
        if rating_node:
            self.log.info('BECKY INFO: Ocena w LC: %s'%rating_node[0])
            rating_value = round(float((rating_node[0]).replace(',','.'))/2)
            self.log.info('BECKY INFO: Found rating: %s'%rating_value)
            self.record_parse_attempt('rating_calibre', 'meta books:rating:value (przeliczenie /2)', rating_value)
            return rating_value
        return None

    # VALUE
    def parse_rating_lc(self, root):
        rating_node = root.xpath('//meta[@property="books:rating:value"]/@content')
        if rating_node:
            # self.log.info('BECKY INFO: Ocena w LC again: %s'%rating_node)
            rating_LC = rating_node[0]
            rating_LC = rating_LC.replace(',','.')
            self.record_parse_attempt('rating_lc', 'meta books:rating:value', rating_LC)
            return rating_LC
        return None

    def parse_rating_lc_count(self,root):
        rating_count = None
        data = self.get_jsonld_data(root, 'aggregateRating.ratingCount')
        if data is None:
            return rating_count
        try:
            if data["aggregateRating"]["ratingCount"]:
                rating_count = str(data["aggregateRating"]["ratingCount"])
                self.log.info('BECKY INFO: Liczba ocen: %s'%rating_count)
                self.record_parse_attempt('rating_count', 'JSON-LD aggregateRating.ratingCount', rating_count)
        except (KeyError, TypeError):
            rating_count = None
        return rating_count

    def parse_isbn(self, root):
        # try <meta>
        isbn_text = None
        try:
            isbn_node = root.xpath('//meta[@property="books:isbn"]/@content')[0]
        except IndexError:
            isbn_node = None

        if isbn_node:
            self.log.info('BECKY INFO: ISBN from meta: %s'%isbn_node)
            #isbn_text = isbn_node[0]
            isbn_text = isbn_node
        else:
            self.log.info('BECKY INFO: Problem z numerem ISBN pobieranym z meta, ale probuje dalej...')

        if isbn_text is None:
            isbn_details = None
            data = self.parse_first(root,'//div[@id="book-details"]//dt[contains(text(),"ISBN:")]/following-sibling::dd[1]/text()','isbn')
            isbn_details = data.strip() if data else None

            if isbn_details is not None:
                self.log.info('BECKY INFO: ISBN from book-details: %s'%isbn_details)
                isbn_text = isbn_details
            else:
                self.log.info('BECKY INFO: Problem z numerem ISBN w book-details')
                isbn_text = None
        return isbn_text

    def parse_publisher(self, root):
        #publisher = root.xpath('//section[@class="container book"]//dt[contains(text(),"Wydawnictwo:")]/following-sibling::dd/a/text()')
        publisher = root.xpath('//span[contains(@class,"book__txt") and contains(normalize-space(.),"Wydawnictwo:")]//a/text()')
        # self.log.info(strip_accents(unicode(publisher)))
        if publisher:
            self.record_parse_attempt('publisher', 'HTML book__txt / Wydawnictwo', publisher[0])
            return publisher[0]
        else:
            self.record_parse_attempt('publisher', 'HTML book__txt / Wydawnictwo', None)
            return None

    def parse_published_date(self, root):
        pub_date_text = None
        data = self.get_jsonld_data(root, 'datePublished')
        # self.log.info(data)
        # pub_date_text = self.parse_first(root,'//dd[@itemprop="datePublished"]/text()','datePublished')
        # pub_date_text = data['itemListElement'][0]['datePublished']
        try:
            if data and data['datePublished']:
                pub_date_text = data['datePublished']
        except (KeyError, TypeError):
            pub_date_text = None
        # self.log.info(pub_date_text)

        if pub_date_text is None:
            pub_date_details = None
            data = self.parse_first(root,'//div[@id="book-details"]//dt[contains(text(),"Data wydania:")]/following-sibling::dd[1]/text()','data_wydania')
            pub_date_details = data.strip() if data else None
            pub_date_text = pub_date_details

        if pub_date_text is not None:
            pub_date = self._convert_date_text(pub_date_text.strip())
            self.log.info('BECKY INFO: Found publication date: %s'%pub_date)
        else:
            self.log.info('BECKY INFO: Not found publication date')
            pub_date = None
        return pub_date

    def parse_first_published_date(self, root):
        first_pub_date_text = None
        data = self.parse_first(root,'//div[@id="book-details"]//dt[contains(@title,"Data pierwszego wydania oryginalnego")]/following-sibling::dd[1]/text()','data_first')
        first_pub_date_text = data

        if first_pub_date_text is not None:
            first_pub_date = self._convert_date_text_exact(first_pub_date_text.strip())
            self.log.info('BECKY INFO: Found first publication date: %s'%first_pub_date)
        else:
            self.log.info('BECKY INFO: Not found first publication date')
            first_pub_date = None
        return first_pub_date

    def parse_first_published_date_pl(self, root):
        first_pub_date_pl_text = None
        data = self.parse_first(root,'//div[@id="book-details"]//dt[contains(@title,"Data pierwszego wydania polskiego")]/following-sibling::dd[1]/text()','data_first_pl')
        first_pub_date_pl_text = data

        if first_pub_date_pl_text is not None:
            first_pub_date_pl = self._convert_date_text_exact(first_pub_date_pl_text.strip())
            self.log.info('BECKY INFO: Found first publication date in Poland: %s'%first_pub_date_pl)
        else:
            self.log.info('BECKY INFO: Not found first publication date in Poland')
            first_pub_date_pl = None
        return first_pub_date_pl

    def _convert_date_text(self, date_text):
        year = int(datetime.datetime.strptime(date_text, '%Y-%m-%d').strftime('%Y'))
        month = int(datetime.datetime.strptime(date_text, '%Y-%m-%d').strftime('%m'))
        day = int(datetime.datetime.strptime(date_text, '%Y-%m-%d').strftime('%d'))
        if day == 1 and month == 1:
            month = 7
        return datetime.datetime(year, month, day, 14, 0, 0)

    def _convert_date_text_exact(self, date_text):
        year = int(datetime.datetime.strptime(date_text, '%Y-%m-%d').strftime('%Y'))
        month = int(datetime.datetime.strptime(date_text, '%Y-%m-%d').strftime('%m'))
        day = int(datetime.datetime.strptime(date_text, '%Y-%m-%d').strftime('%d'))
        return datetime.datetime(year, month, day, 14, 0, 0)

    def parse_pages(self, root):
        data = self.get_jsonld_data(root, 'numberOfPages')
        try:
            if data and data['numberOfPages']:
                pages_text = data['numberOfPages']
            else:
                pages_text = None
        except (KeyError, TypeError):
            pages_text = None
        if pages_text is not None:
            pages = str(pages_text).strip()
            self.log.info('BECKY INFO: Found number of pages: %s'%pages)
        else:
            self.log.info('BECKY INFO: Not found number of pages')
            pages = None
        return pages

    def parse_tytul_oryginalu(self, root):
        tytul_oryginalu_node = self.parse_first(root,'//section[@class="container book"]//dt[contains(text(),"Tytuł oryginału")]/following-sibling::dd/text()','tytul_oryginalu')
        # self.log.info('BECKY INFO: Tytul oryginalu: %s'%tytul_oryginalu_node)
        if tytul_oryginalu_node:
            tytul_oryginalu = tytul_oryginalu_node
        else:
            tytul_oryginalu = None
        return tytul_oryginalu

    def parse_inne_wydania(self, root):
        inne_wydania_istnieja = root.xpath('//button[@id="buttonShowOtherEditions"]/text()')
        # self.log.info('BECKY INFO: inne_wydania_istnieja: %s'%inne_wydania_istnieja)
        if inne_wydania_istnieja:
            self.log.info('BECKY INFO: Istnieja inne wydania tej ksiazki')
        else:
            return None
        return inne_wydania_istnieja

    def parse_inne_wydania_all(self, root):
        # Pelna lista znajduje sie na osobnej stronie /ksiazka/wydania/ID/slug.
        # Jesli jej pobranie sie nie powiedzie, korzystamy ze skroconej listy
        # osadzonej na stronie ksiazki, tak jak w poprzedniej wersji wtyczki.
        editions_root = None
        match = re.search(r'/ksiazka/(\d+)(?:/([^/?#]+))?', self.url)
        if match:
            editions_url = 'https://lubimyczytac.pl/ksiazka/wydania/' + match.group(1)
            if match.group(2):
                editions_url += '/' + match.group(2)
            try:
                response = self.browser.open_novisit(editions_url, timeout=self.timeout)
                editions_raw = response.read().strip()
                if not isinstance(editions_raw, unicode):
                    editions_raw = editions_raw.decode('utf-8', errors='replace')
                editions_root = fromstring(clean_ascii_chars(editions_raw.encode('utf-8')))
                self.log.info('BECKY INFO: Pobrano strone pelnej listy wydan: %s' % editions_url)
            except Exception as e:
                self.log.warning('BECKY INFO: Nie udalo sie pobrac pelnej listy wydan: %s' % e)

        edition_links = []
        if editions_root is not None:
            for node in editions_root.xpath(
                    '//div[@id="editionsList"]//a[contains(concat(" ", normalize-space(@class), " "), " book-card__title ")]'):
                href = node.get('href')
                title = ''.join(node.itertext()).strip()
                if href and title:
                    if href.startswith('/'):
                        href = 'https://lubimyczytac.pl' + href
                    if href not in [item[0] for item in edition_links]:
                        edition_links.append((href, title))

        # Fallback dla zmian po stronie serwisu lub problemow z polaczeniem.
        if not edition_links:
            links = root.xpath('//div[@id="other-editions"]/div/div//a')
            for node in links:
                href = node.get('href')
                img_alt = node.xpath('.//img/@alt')
                title = img_alt[0].strip() if img_alt else ''.join(node.itertext()).strip()
                if href and title:
                    if href.startswith('/'):
                        href = 'https://lubimyczytac.pl' + href
                    if href not in [item[0] for item in edition_links]:
                        edition_links.append((href, title))

        if not edition_links:
            self.log.info('BECKY INFO: Brak linkow do innych wydan.')
            return None

        # Tytuly z pelnej listy wykorzystujemy rowniez w liscie skroconej.
        # Nie wyciagamy ich ze slugow URL, bo slug nie musi byc tytulem.
        self.inne_wydania_tytuly_short = [title for href, title in edition_links]
        self.log.info('BECKY INFO: Znaleziono wydan: %d' % len(edition_links))
        self.log.info('BECKY INFO: Tytuly innych wydan (wszystkie):')
        self.log.info([strip_accents(unicode(title)) for href, title in edition_links])
        self.log.info('BECKY INFO: Linki do innych wydan:')
        inne_wydania_dane = '<br>'.join(
            '<a href="%s">%s</a>' % (href, title)
            for href, title in edition_links
        )
        return '<p id="lista-innych-wydan">Lista innych wydań:<br>' + inne_wydania_dane + '</p>'

    def parse_inne_wydania_short(self, root):
        # Korzystamy z rzeczywistych tytulow odczytanych juz z pelnej listy
        # wydan. Slugi URL sa tylko awaryjnym zrodlem, gdy pobranie listy
        # pelnej nie powiodlo sie.
        inne_wydania_tytuly = getattr(self, 'inne_wydania_tytuly_short', None)
        if not inne_wydania_tytuly:
            links = root.xpath('//div[@id="other-editions"]/div/div//a')
            inne_wydania_tytuly = []
            for node in links:
                img_alt = node.xpath('.//img/@alt')
                title = img_alt[0].strip() if img_alt else ''.join(node.itertext()).strip()
                if title:
                    inne_wydania_tytuly.append(title)
            if not inne_wydania_tytuly:
                hrefs = root.xpath('//div[@id="other-editions"]/div/div//a/@href')
                inne_wydania_tytuly = [str(w.rpartition('/')[2]) for w in hrefs]
        inne_wydania_wszystkie_short = None
        lista_innych_wydan_short = None
        if inne_wydania_tytuly:
            inne_wydania_tytuly = [strip_accents(unicode(str(w).strip())) for w in inne_wydania_tytuly]
            inne_wydania_tytuly_bez_powtorzen = []
            for chwiloword in inne_wydania_tytuly:
                for i in range(len(inne_wydania_tytuly_bez_powtorzen)):
                    if inne_wydania_tytuly_bez_powtorzen[i].lower() == chwiloword.lower():
                        inne_wydania_tytuly_bez_powtorzen[i] = min(chwiloword, inne_wydania_tytuly_bez_powtorzen[i])
                        break
                else:
                    inne_wydania_tytuly_bez_powtorzen.append(chwiloword)
            # inne_wydania_tytuly_bez_powtorzen_temp = [strip_accents(unicode(str(w))) for w in inne_wydania_tytuly_bez_powtorzen]
            # self.log.info('BECKY INFO: Tytuly innych wydan (bez powtorzen): ',inne_wydania_tytuly_bez_powtorzen_temp)
            inne_wydania_dane_short = ' • '.join('%s' % t for t in inne_wydania_tytuly_bez_powtorzen)
            if len(inne_wydania_tytuly_bez_powtorzen) == 1:

                if len(inne_wydania_tytuly) == 1:
                    inne_wydania_wszystkie_short = '<p id="lista-innych-wydan-short">Tytuł innego wydania: ' + inne_wydania_dane_short + '</p>'
                else:
                    inne_wydania_wszystkie_short = '<p id="lista-innych-wydan-short">Wszystkie inne wydania mają ten sam tytuł: ' + inne_wydania_dane_short + '</p>'
            else:
                inne_wydania_wszystkie_short = '<p id="lista-innych-wydan-short">Tytuły innych wydań: ' + inne_wydania_dane_short + '</p>'
            # inne_wydania_dane[inwyd] =  + ' ' + inne_wydania_linki[inwyd]
            # TypeError: list indices must be integers, not lxml.etree._ElementUnicodeResult
            # self.log.info ('BECKY INFO: Kumulacja innych wydan:')
            # self.log.info (inne_wydania_wszystkie)
        if inne_wydania_wszystkie_short:
            lista_innych_wydan_short = inne_wydania_wszystkie_short
        else:
            lista_innych_wydan_short = None
        return lista_innych_wydan_short

    def parse_comments(self, root):
        comments = ''

        #description_node = root.xpath('//section[@class="container book"]//div[@class="collapse-content"]')
        description_node = root.xpath('//div[contains(@id,"book-description")]')
        
        if description_node:
            for zrodla in root.xpath('//p[@class="source"]'):
                zrodla.getparent().remove(zrodla)
            comments = tostring(description_node[0], method='html')
            comments = sanitize_comments_html(comments)

        else:
            # try <meta>
            description_node = root.xpath('//meta[@property="og:description"]/@content')
            if description_node:
                comments = description_node[0]
                comments = sanitize_comments_html(comments)
        return comments

    def parse_tags(self, root):
        tags = None
        try:
            # tags_from_genre = root.xpath('//section[@class="container book"]//dt[contains(text(),"Kategoria:")]/following-sibling::dd/text()')[1]
            # tags_from_genre = root.xpath('//section[@class="container book"]//a[@class="book__category"]')
            tags_from_genre = root.xpath('//nav[@aria-label="breadcrumbs"]//a[contains(@href,"/ksiazki/k/")]/span[@itemprop="name"]/text()')
            if tags_from_genre:
                # tags_from_genre_temp = strip_accents(unicode(tags_from_genre.strip()))
                tags_from_genre_temp = strip_accents(unicode(''.join(tags_from_genre).strip()))
                self.log.info('BECKY INFO: Tags (genre): %s'%tags_from_genre_temp)
                tags = tags_from_genre
                tags = [w.replace(', itd.',  ' itd.') for w in tags]
                return tags
            else:
                self.log.info('BECKY INFO: No tags (genre)')
                return None
        except:
            return tags

    def parse_tags_keywords(self, root):
        tags_keywords = list()
        try:
            tags_from_keywords = root.xpath('//section[@class="container book"]//dt[contains(text(),"Tagi:")]/following-sibling::dd/a/text()')
            if tags_from_keywords:
                # tags_from_keywords_temp = [strip_accents(unicode(w.strip())) for w in tags_from_keywords]
                # self.log.info('BECKY INFO: Tags (keywords): %s'%tags_from_keywords_temp)
                for tag in tags_from_keywords:
                    if tag not in tags_keywords:
                        tags_keywords.append(tag.strip())
            if tags_keywords:
                self.log.info('BECKY INFO: Unikatowe tags (keywords): %s'%unique(tags_keywords))
                return unique(tags_keywords)
            else:
                self.log.info('BECKY INFO: No tags (keywords)')
                return None
        except:
            return list(tags_keywords)

    def parse_languages(self, root):
        lang = self.parse_first(root,'//section[@class="container book"]//dt[contains(text(),"Język:")]/following-sibling::dd/text()','inLanguage')
        # self.log.info('Lang: %s'%lang)
        languages = list()
        if lang:
            self.record_parse_attempt('language', 'HTML etykieta Język', lang)
            if "polski" in lang:
                languages.append("pol")
            if "angielski" in lang:
                languages.append("eng")
        if not lang:
            self.record_parse_attempt('language', 'HTML etykieta Język', None)
        return languages


    def is_placeholder_cover(self, url):

        if not url:
            return True

        # Logo LC
        if 'lc-logo' in url:
            return True

        # Domyślna okładka zastępcza
        if 'default-book-' in url:
            return True

        # SVG placeholder
        if url.endswith('.svg'):
            return True

        return False

    
    def parse_cover(self, root):

        img_url = None

        #
        # 1. JSON-LD
        #
        data = self.get_jsonld_data(root)

        if data:

            json_image = data.get('image')

            if json_image and not self.is_placeholder_cover(json_image):

                self.log.info(
                    'BECKY INFO: Found cover (json): %s'
                    % json_image
                )

                img_url = json_image

        #
        # 2. preload image
        #
        if not img_url:

            preload_img = root.xpath(
                '//link[@rel="preload"][@as="image"]/@href'
            )

            if preload_img:

                if not self.is_placeholder_cover(preload_img[0]):

                    self.log.info(
                        'BECKY INFO: Found cover (preload): %s'
                        % preload_img[0]
                    )

                    img_url = preload_img[0]

        #
        # 3. HTML IMG
        #
        if not img_url:

            img_nodes = root.xpath(
                '//div[contains(@class,"book-cover")]//img/@src'
            )

            if img_nodes:

                if not self.is_placeholder_cover(img_nodes[0]):

                    self.log.info(
                        'BECKY INFO: Found cover (html): %s'
                        % img_nodes[0]
                    )

                    img_url = img_nodes[0]

        #
        # 4. og:image fallback
        #
        if not img_url:

            og_img = root.xpath(
                '//meta[@property="og:image"]/@content'
            )

            if og_img:

                if not self.is_placeholder_cover(og_img[0]):

                    self.log.info(
                        'BECKY INFO: Found cover (og:image): %s'
                        % og_img[0]
                    )

                    img_url = og_img[0]

        #
        # 5. Walidacja URL
        #
        if img_url:

            try:

                info = self.browser.open_novisit(
                    img_url,
                    timeout=self.timeout
                ).info()

            except:

                self.log.warning(
                    'BECKY HINT: Ten problem moze byc zwiazany z antywirusem lub firewallem'
                )

                info = None

            if info is not None:

                if info.get('Content-Length') is not None:

                    if int(info.get('Content-Length')) > 1000:
                        return img_url

                    else:
                        self.log.warning(
                            'Broken image for url: %s'
                            % img_url
                        )

                else:
                    return img_url

        return None
    
    def clean_downloaded_metadata(self, mi):
        replaceISBN = cfg.plugin_prefs[cfg.STORE_NAME].get(cfg.REPLACE_ISBN, cfg.DEFAULT_STORE_VALUES[cfg.REPLACE_ISBN])
        swapnames = cfg.plugin_prefs[cfg.STORE_NAME].get(cfg.SWAP_NAMES, cfg.DEFAULT_STORE_VALUES[cfg.SWAP_NAMES])


        # asTags = cfg.plugin_prefs[cfg.STORE_NAME].get(cfg.TAGS_AS, cfg.DEFAULT_STORE_VALUES[cfg.TAGS_AS])
        '''
        Custom implementation - without title capitalizing
        '''
        # self.log.warning('BECKY INFO: mi-authors przed: %s'%mi.authors)
        mi.authors = fixauthors(mi.authors)
        # self.log.warning('BECKY INFO: mi-authors po: %s'%mi.authors)


        if swapnames:
            # old_authors = [a.strip().replace('|', ',') for a in mi.authors.split(',')]
            old_authors = mi.authors
            new_authors = [swap_names(a) for a in old_authors]
            mi.authors = new_authors
        # Pierwszą literę każdego elementu dajemy od wielkiej litery
        mi.tags = [re.sub('[a-ząćęłńóśźżA-ZĄĆĘŁŃÓŚŹŻ]', lambda x: x.group().upper(), y, 1) for y in mi.tags]
        mi.tags = list(mi.tags)
        if replaceISBN == 1:
            mi.isbn = check_isbn(mi.isbn)

def get_int_or_float(v):
    number_as_float = float(v)
    number_as_int = int(number_as_float)
    return number_as_int if number_as_float == number_as_int else number_as_float

def odmiana(x, y):
    x = int(x)
    if x == 0:
        return " "
    else:
        inumber = x % 10
        iinumber = x % 100
        if x == 1:
            y = y[0]
        elif iinumber > 4 and iinumber < 22:
            y = y[2]
        elif inumber>1 and inumber<=4:
            y = y[1]
        else:
            y = y[2]
        return " " + y

def strip_accents(s):
    if s is None:  # or s is not str:
        return s
    else:
        symbols = ("öÖüÜóÓőŐúÚéÉáÁűŰíÍąĄćĆęĘłŁńŃóÓśŚźŹżŻ",
                   "oOuUoOoOuUeEaAuUiIaAcCeElLnNoOsSzZzZ")
        tr = dict([(ord(a), ord(b)) for (a, b) in zip(*symbols)])
        return s.translate(tr)  # .lower()

# function to get unique values
def unique(list1):

    # intilize a null list
    unique_list = []

    # traverse for all elements
    for x in list1:
        # check if exists in unique_list or not
        if x not in unique_list:
            unique_list.append(x)
    # print list
    return unique_list


def swap_names(a):
    if ',' in a:
        parts = a.split(',')
        if len(parts) <= 1:
            return a
        surname = parts[0]
        return '%s %s' % (' '.join(parts[1:]), surname)
    else:
        parts = a.split(None)
        if len(parts) <= 1:
            return a
        surname = parts[-1]
        return '%s %s' % (surname, ' '.join(parts[:-1]))
